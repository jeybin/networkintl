<?php
namespace Jeybin\Networkintl\App\Http\Controllers;


final class AccessTokenController{
    
    
    public function __invoke(){

        

    }



}


